import java.awt.*; // Importing awt for layout and graphics
import javax.swing.*; // Importing swing for GUI components
import java.awt.event.*; // Importing event for action listeners

// Class to display the score after the quiz
public class Score extends JFrame implements ActionListener {

    // Constructor to initialize the score display
    Score(String name, int score) {
        // Set the size and position of the frame
        setBounds(400, 150, 750, 550);
        // Set the background color of the content pane
        getContentPane().setBackground(Color.WHITE);
        // Disable default layout manager
        setLayout(null);
        
        // Load and scale the score image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/score.png"));
        Image i2 = i1.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        // Create and position the image label
        JLabel image = new JLabel(i3);
        image.setBounds(0, 120, 300, 250);
        add(image);
        
        // Create and position the heading label with the player's name
        JLabel heading = new JLabel("Thank you " + name + " for playing Simple Minds");
        heading.setBounds(45, 30, 700, 30);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(heading);
        
        // Create and position the label to show the player's score
        JLabel lblscore = new JLabel("Your score is " + score);
        lblscore.setBounds(350, 200, 300, 30);
        lblscore.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(lblscore);
        
        // Create and configure the "Play Again" button
        JButton submit = new JButton("Play Again");
        submit.setBounds(380, 270, 120, 30);
        submit.setBackground(new Color(30, 144, 255));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this); // Add action listener to handle button clicks
        add(submit);
        
        // Make the frame visible
        setVisible(true);
    }
    
    // Handle button clicks
    public void actionPerformed(ActionEvent ae) {
        // Hide the current frame and open the login screen
        setVisible(false);
        new Login();
    }

    // Main method to run the Score frame
    public static void main(String[] args) {
        new Score("User", 0); // Create a Score frame with default values
    }
}