import java.awt.*; // Importing AWT package for GUI components
import java.awt.event.*; // Importing AWT event package for handling actions

import javax.swing.*; // Importing Swing package for extended GUI components

// Creating a Login class that extends JFrame (GUI window) and implements ActionListener (for button actions)
public class Login extends JFrame implements ActionListener {
    
    // Declaring buttons and text field as global, so they can be accessed in the entire class
    JButton rules, back; 
    JTextField tfname; 

    // Constructor of the Login class
    Login() {
        // Setting the visibility, size, and location of the JFrame
        setVisible(true);
        setSize(1200, 500); // Setting the width and height of the window
        setLocation(120, 100); // Setting the position of the window on the screen
        
        // Setting the background color of the content pane to white
        getContentPane().setBackground(Color.WHITE);

        // Adding an image to the frame
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login2.jpg")); // Load image from resources
        JLabel image = new JLabel(i1); // Adding the image to a JLabel
        add(image); // Adding the image to the frame

        // Setting the layout to null to allow manual component positioning
        setLayout(null); 
        image.setBounds(0, 0, 600, 500); // Setting the position and size of the image

        // Adding a heading label to the frame
        JLabel heading = new JLabel("Simple Minds");
        add(heading); // Adding the label to the frame
        heading.setBounds(750, 60, 300, 45); // Setting the position and size of the heading
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 40)); // Setting the font style and size
        heading.setForeground(new Color(30, 40, 250)); // Setting the font color

        // Adding a label for name input
        JLabel name = new JLabel("Enter Your Name Here");
        add(name); // Adding the label to the frame
        name.setBounds(780, 150, 200, 20); // Setting the position of the label
        name.setFont(new Font("Mongolian Baiti", Font.BOLD, 20)); // Setting the font style and size
        name.setForeground(new Color(30, 40, 250)); // Setting the font color

        // Adding a text field for user to input their name
        tfname = new JTextField();
        add(tfname); // Adding the text field to the frame
        tfname.setBounds(735, 190, 300, 20); // Setting the position and size of the text field
        tfname.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Setting the font style and size

        // Adding a "Rules" button
        rules = new JButton("Rules");
        add(rules); // Adding the button to the frame
        rules.setBounds(735, 270, 120, 25); // Setting the position and size of the button
        rules.setBackground(new Color(30, 144, 254)); // Setting the button's background color
        rules.setForeground(Color.WHITE); // Setting the button's text color
        rules.addActionListener(this); // Adding an action listener to handle button click

        // Adding a "Back" button
        back = new JButton("Back");
        add(back); // Adding the button to the frame
        back.setBounds(915, 270, 120, 25); // Setting the position and size of the button
        back.setBackground(new Color(30, 144, 254)); // Setting the button's background color
        back.setForeground(Color.WHITE); // Setting the button's text color
        back.addActionListener(this); // Adding an action listener to handle button click
    }

    // Method to handle button clicks (event handling)
    public void actionPerformed(ActionEvent ae) {
        // If the "Rules" button is clicked
        if(ae.getSource() == rules){
            String name = tfname.getText(); // Get the name entered in the text field
            setVisible(false); // Hide the current frame (Login frame)
            new Rules(name); // Open the Rules frame and pass the name
        } 
        // If the "Back" button is clicked
        else if(ae.getSource() == back){
            setVisible(false); // Hide the current frame
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
       new Login(); // Create an instance of Login class (Anonymous object)
    }
}