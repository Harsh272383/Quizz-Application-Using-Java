import javax.swing.*; // Importing Swing package for GUI components
import java.awt.*; // Importing AWT package for GUI components
import java.awt.event.*; // Importing AWT event package for handling actions

// Creating a Rules class that extends JFrame (for GUI window) and implements ActionListener (for button actions)
public class Rules extends JFrame implements ActionListener {
    String name; // Storing the user's name
    JButton start, back; // Declaring buttons for "Start" and "Back"

    // Constructor to initialize the Rules frame, accepts 'name' as a parameter
    Rules(String name){
        // Setting visibility, size, and location of the JFrame
        setVisible(true);
        setSize(800, 650); // Setting the width and height of the window
        setLocation(350, 100); // Positioning the window on the screen
        getContentPane().setBackground(Color.WHITE); // Setting the background color of the window to white

        setLayout(null); // Using null layout for manual component positioning

        // Creating and setting a heading label with the user's name
        JLabel heading = new JLabel("Welcome " + name + " to simple minds");
        add(heading); // Adding the label to the frame
        heading.setBounds(50, 10, 700, 35); // Setting the position and size of the heading
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 30)); // Setting the font style and size
        heading.setForeground(new Color(30, 144, 254)); // Setting the font color

        // Storing the name for later use
        this.name = name;

        // Creating a label to display the rules
        JLabel rules = new JLabel();
        add(rules); // Adding the label to the frame
        rules.setBounds(20, 90, 700, 350); // Setting the position of the rules text
        rules.setFont(new Font("Tahoma", Font.PLAIN, 16)); // Setting the font style and size for the rules
        // Setting the rules text in HTML format to allow line breaks and formatting
        rules.setText(
            "<html>"+ 
                "1. You are trained to be a programmer and not a storyteller, answer point to point" + "<br><br>" +
                "2. Do not unnecessarily smile at the person sitting next to you, they may also not know the answer" + "<br><br>" +
                "3. You may have a lot of options in life but here all the questions are compulsory" + "<br><br>" +
                "4. Crying is allowed but please do so quietly." + "<br><br>" +
                "5. Only a fool asks and a wise answers (Be wise, not otherwise)" + "<br><br>" +
                "6. Do not get nervous if your friend is answering more questions, maybe he/she is doing Jai Mata Di" + "<br><br>" +
                "7. Brace yourself, this paper is not for the faint-hearted" + "<br><br>" +
                "8. May you know more than what John Snow knows, Good Luck" + "<br><br>" +
            "<html>"
        );

        // Adding the "Back" button to the frame
        back = new JButton("Back");
        add(back); // Adding the button to the frame
        back.setBounds(250, 500, 100, 30); // Setting the position and size of the button
        back.setBackground(new Color(30, 144, 254)); // Setting the button's background color
        back.setForeground(Color.WHITE); // Setting the button's text color
        back.addActionListener(this); // Adding an action listener to handle button click

        // Adding the "Start" button to the frame
        start = new JButton("Start");
        add(start); // Adding the button to the frame
        start.setBounds(400, 500, 100, 30 ); // Setting the position and size of the button
        start.setBackground(new Color(30, 144, 254)); // Setting the button's background color
        start.setForeground(Color.WHITE); // Setting the button's text color
        start.addActionListener(this); // Adding an action listener to handle button click
    }
    
    // Method to handle button clicks
    public void actionPerformed(ActionEvent ae) {
        // If "Start" button is clicked (Currently does nothing, you can add your logic here)
        if(ae.getSource() == start){
            setVisible(false); // Hide the current frame (Rules frame)
            new Quiz(name); // Open the Quiz frame and pass the name
        } 
        // If "Back" button is clicked, go back to the Login screen
        else if(ae.getSource() == back){
            setVisible(false); // Hide the current Rules frame
            new Login(); // Open the Login frame again
        }
    }

    // Main method to run the Rules class independently
    public static void main(String[] args) {
        new Rules("User"); // Creating an instance of Rules with the name "User"
    }
}
